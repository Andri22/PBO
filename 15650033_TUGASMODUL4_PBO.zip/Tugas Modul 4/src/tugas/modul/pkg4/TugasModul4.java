/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas.modul.pkg4;

import java.util.Scanner;

/**
 *
 * @author Andri
 */
public class TugasModul4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        double a = 500000;
        double b = 1000000;
        int akhir;
        int diskon;

        Scanner input = new Scanner(System.in);
        System.out.println("Program Penghitung Diskon");
        System.out.print("Masukan Total Belanja = ");
        double total = input.nextDouble();
        boolean hasil = true;

        if (total < a) {
            diskon = (int) ((total * 5) / 100);
            System.out.println("Diskon Harga = " + diskon);
            akhir = (int) (total - diskon);
            System.out.print("Total Belanja = " + akhir);
        } else if (total >= a && total <= b) {
            diskon = (int) ((total * 10) / 100);
            System.out.println("Diskon Harga = " + diskon);
            akhir = (int) (total - diskon);
            System.out.print("Total Belanja = " + akhir);
        } else if (total > b) {
            diskon = (int) ((total * 15) / 100);
            System.out.println("Diskon Harga = " + diskon);
            akhir = (int) (total - diskon);
            System.out.print("Total Belanja = " + akhir);
        }

    }

}
