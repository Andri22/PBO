/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KonversiBilangan;

import java.util.Scanner;

/**
 *
 * @author Andri
 */
public class Konversi {

    public static void main(String[] args) {

        String bil;
        int[] arr_bil = new int[1000];
        String[] st = new String[1000];
        double hasil = 0, result = 0;
        int a = 0;
        char t;

        Scanner input = new Scanner(System.in);
        System.out.println("===PROGRAM KONVERSI BILANGAN BINER KE DESIMAL==");
        System.out.print("Masukan Bilangan Biner = ");
        bil = input.next();

        for (int i = 0; i < bil.length(); i++) {
            t = bil.charAt(i);
            st[i] = Character.toString(t);
        }
        for (int i = bil.length() - 1; i >= 0; i--) {
            arr_bil[a] = Integer.parseInt(st[i]);
            hasil = arr_bil[a] * (Math.pow(2, a));
            result = result + hasil;
            a++;
        }

        {
            int resultIn = (int) result;
            System.out.println("Bilangan Binner : " + bil);
            System.out.println("Bilangan Desimal : " + resultIn);
        }
    }

}
